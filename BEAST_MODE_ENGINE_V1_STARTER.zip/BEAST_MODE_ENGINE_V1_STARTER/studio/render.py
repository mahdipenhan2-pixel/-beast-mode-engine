#!/usr/bin/env python3
"""BEAST MODE V1 starter renderer. Requires FFmpeg and FFprobe."""
from pathlib import Path
import json
import subprocess
import sys

BASE = Path(__file__).resolve().parent
INPUT = BASE / "input"
AUDIO = BASE / "audio" / "music.mp3"
WATERMARK = BASE / "assets" / "watermark.png"
OUTPUT_DIR = BASE / "output"
OUTPUT = OUTPUT_DIR / "BEAST-MODE-FINAL.mp4"

def run(cmd):
    print("+", " ".join(map(str, cmd)))
    subprocess.run(cmd, check=True)

def probe_duration(path):
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", str(path)],
        check=True, capture_output=True, text=True
    )
    return float(result.stdout.strip())

def main():
    clips = sorted(
        [p for p in INPUT.iterdir() if p.suffix.lower() in {".mp4", ".mov", ".m4v"}],
        key=lambda p: p.name.lower()
    )
    if not clips:
        sys.exit("ERROR: No video clips found in studio/input/. Add at least one MP4 or MOV.")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    normalized = []
    for i, clip in enumerate(clips, 1):
        target = OUTPUT_DIR / f"normalized_{i:02d}.mp4"
        # Fit/crop to vertical 9:16. Audio is removed from source clips for a clean music mix.
        vf = (
            "scale=1080:1920:force_original_aspect_ratio=increase,"
            "crop=1080:1920,fps=30,setsar=1,"
            "format=yuv420p"
        )
        run([
            "ffmpeg", "-y", "-i", str(clip), "-an",
            "-vf", vf, "-c:v", "libx264", "-preset", "veryfast",
            "-crf", "20", str(target)
        ])
        normalized.append(target)

    concat_file = OUTPUT_DIR / "concat_list.txt"
    concat_file.write_text(
        "".join(f"file '{p.resolve().as_posix()}'\n" for p in normalized),
        encoding="utf-8"
    )
    joined = OUTPUT_DIR / "joined.mp4"
    run([
        "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat_file),
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
        "-pix_fmt", "yuv420p", str(joined)
    ])

    if AUDIO.exists():
        duration = probe_duration(joined)
        cmd = [
            "ffmpeg", "-y", "-i", str(joined), "-stream_loop", "-1",
            "-i", str(AUDIO)
        ]
        if WATERMARK.exists():
            cmd += ["-i", str(WATERMARK)]
            filter_complex = (
                "[0:v][2:v]overlay=W-w-48:H-h-48:format=auto[v];"
                "[1:a]atrim=0:" + str(duration) + ",asetpts=PTS-STARTPTS,"
                "afade=t=out:st=" + str(max(0, duration-1.5)) +
                ":d=1.5[a]"
            )
            cmd += ["-filter_complex", filter_complex, "-map", "[v]", "-map", "[a]"]
        else:
            cmd += [
                "-map", "0:v", "-map", "1:a",
                "-af", f"atrim=0:{duration},asetpts=PTS-STARTPTS,"
                       f"afade=t=out:st={max(0, duration-1.5)}:d=1.5"
            ]
        cmd += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
                "-c:a", "aac", "-b:a", "192k", "-shortest", "-pix_fmt", "yuv420p",
                str(OUTPUT)]
        run(cmd)
    else:
        # No music supplied: preserve a silent final video rather than inventing audio.
        run([
            "ffmpeg", "-y", "-i", str(joined), "-c", "copy", str(OUTPUT)
        ])

    print(json.dumps({
        "status": "success",
        "clips": [p.name for p in clips],
        "music_added": AUDIO.exists(),
        "watermark_added": WATERMARK.exists(),
        "output": str(OUTPUT)
    }, indent=2))

if __name__ == "__main__":
    main()
