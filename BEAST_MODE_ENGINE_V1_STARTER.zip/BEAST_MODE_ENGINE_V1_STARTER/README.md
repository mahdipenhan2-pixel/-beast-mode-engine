# BEAST MODE — Engine V1 Starter

This is the first **working foundation** for BEAST MODE's post-production engine.
It does not automate Google Flow. You generate clips in Flow, download them, and place them in `studio/input/`.

## What this version does
- Combines uploaded clips in filename order.
- Converts the result to vertical 1080x1920 MP4.
- Adds a music track from `studio/audio/music.mp3` when supplied.
- Adds an optional watermark image from `studio/assets/watermark.png`.
- Uploads the finished MP4 as a GitHub Actions artifact.

## What it does NOT do yet
- Generate videos inside Google Flow.
- Generate original music.
- Automatically fetch audience comments.
- Guarantee that a music track has commercial rights.

## Folder layout
- `studio/input/` — put clips here, named `01.mp4`, `02.mp4`, etc.
- `studio/audio/music.mp3` — optional soundtrack.
- `studio/assets/watermark.png` — optional transparent PNG watermark.
- `studio/output/` — local output folder (Git ignores rendered files).

## Run it on GitHub
1. Create a **new, separate GitHub repository** named `beast-mode-engine`.
2. Upload all files from this ZIP, preserving the folder structure.
3. Upload your Flow clips into `studio/input/`.
4. Optionally upload `music.mp3` and `watermark.png` to the folders above.
5. Open **Actions** → **BEAST MODE Render** → **Run workflow**.
6. Download the `BEAST-MODE-FINAL` artifact when the workflow finishes.

Keep your existing NFP repository untouched.

## Important
The first render version uses a simple sequential edit. Beat-sync, smart clip selection,
signature intro/outro, and a polished web interface are later upgrades after this basic
render pipeline is proven.
